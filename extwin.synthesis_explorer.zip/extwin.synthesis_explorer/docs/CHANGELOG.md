# Changelog
- Initial version of Assets from https://synthesis.extwin.com Extension
